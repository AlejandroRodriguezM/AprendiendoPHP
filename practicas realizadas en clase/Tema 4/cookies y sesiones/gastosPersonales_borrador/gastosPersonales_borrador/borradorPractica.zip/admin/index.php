<?php

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Gestión de Usuarios</title>
        <link rel="stylesheet" type="text/css" href="../css/estilos.css">
    </head>
    <body>
		<header><h1>Gestión de Usuarios</h1></header>
		<nav>Administrar Usuarios</nav>
        <main>
			<div id="menu">
				<a href="nuevo_usuario.php?<?php  ?>">Nuevo Usuario</a>
				
				<a href="modificar_usuario.php?<?php  ?>">Modificar Usuario</a>
				<a href="borrar_usuario.php?<?php  ?>">Borrar Usuario</a>
				<a href="../">Salir</a>
			</div>
		</main>
    </body>
</html>